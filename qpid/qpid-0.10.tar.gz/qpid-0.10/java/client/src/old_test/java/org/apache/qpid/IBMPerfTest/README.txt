These JNDI setup tools are mainly for use in conjunction with the IBM JMS Performance Harness available here:
The jar should be placed in the client/test/lib/ directory.

http://www.alphaworks.ibm.com/tech/perfharness


These JNDI classes use the the SUN FileSystem context.
There are two jar files that should be placed in your client/test/lib directory.

http://javashoplm.sun.com/ECom/docs/Welcome.jsp?StoreId=22&PartDetailId=7110-jndi-1.2.1-oth-JPR&SiteId=JSC&TransactionId=noreg

